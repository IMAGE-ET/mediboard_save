
DROP TABLE IF EXISTS `critere_duree_aati`;
DROP TABLE IF EXISTS `duree_indicative_aati`;
DROP TABLE IF EXISTS `motif_aati`;
--
-- Table structure for table `motif_aati`
--

CREATE TABLE `motif_aati` (
  `code` varchar(8) NOT NULL,
  `libelle` varchar(80) NOT NULL,
  `type` enum('groupe','motif') NOT NULL,
  `complement` enum('0','1') DEFAULT '0',
  `codification` varchar(10) DEFAULT NULL,
  `correspondance` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=MyISAM;

--
-- Table structure for table `duree_indicative_aati`
--

CREATE TABLE `duree_indicative_aati` (
  `duree_indicative_id` int(11) NOT NULL,
  `code_motif` varchar(8) NOT NULL,
  PRIMARY KEY (`duree_indicative_id`)
) ENGINE=MyISAM;

--
-- Table structure for table `critere_duree_aati`
--

CREATE TABLE `critere_duree_aati` (
  `critere_id` int(11) NOT NULL,
  `text` varchar(100) DEFAULT NULL,
  `duree` int(3) DEFAULT NULL,
  `unite_duree` varchar(1) DEFAULT NULL,
  `parent_id` varchar(11) NOT NULL,
  `parent_class` varchar(50) NOT NULL,
  PRIMARY KEY (`critere_id`)
) ENGINE=MyISAM;
