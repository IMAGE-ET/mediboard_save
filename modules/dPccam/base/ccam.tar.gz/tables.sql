-- 
-- Base de données: `ccamV2`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `acces1`
-- 

DROP TABLE IF EXISTS `acces1`;
CREATE TABLE `acces1` (
  `CODE` char(1) NOT NULL default '',
  `ACCES` varchar(80) default NULL,
  `LIBELLE` varchar(255) default NULL,
  PRIMARY KEY  (`CODE`),
  KEY `ACCES` (`ACCES`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `acces2`
-- 

DROP TABLE IF EXISTS `acces2`;
CREATE TABLE `acces2` (
  `PERE` char(1) default NULL,
  `LIBELLE` varchar(150) default NULL,
  KEY `PERE` (`PERE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `action1`
-- 

DROP TABLE IF EXISTS `action1`;
CREATE TABLE `action1` (
  `VERBE` varchar(20) NOT NULL default '',
  `CODE` char(1) default NULL,
  `LIBELLE` varchar(255) default NULL,
  PRIMARY KEY  (`VERBE`),
  KEY `CODE` (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `action2`
-- 

DROP TABLE IF EXISTS `action2`;
CREATE TABLE `action2` (
  `VERBE` varchar(30) default NULL,
  `CODE` char(1) default NULL,
  `SUBSTANTIF` varchar(20) default NULL,
  KEY `ACTION` (`VERBE`),
  KEY `CODE` (`CODE`),
  KEY `VERBE` (`SUBSTANTIF`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `motcle`
-- 

DROP TABLE IF EXISTS `motcle`;
CREATE TABLE `motcle` (
  `mtcle` varchar(40) NOT NULL default '',
  `codacc` varchar(13) NOT NULL default '',
  `phonmtcle` varchar(40) default NULL,
  `syn` varchar(40) default NULL,
  KEY `mtcle` (`mtcle`),
  KEY `codacc` (`codacc`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `synonymes`
-- 

DROP TABLE IF EXISTS `synonymes`;
CREATE TABLE `synonymes` (
  `MOT` varchar(30) NOT NULL default '',
  `SYNONYME` varchar(30) NOT NULL default '',
  KEY `MOT` (`MOT`),
  KEY `SYNONYME` (`SYNONYME`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `topographie1`
-- 

DROP TABLE IF EXISTS `topographie1`;
CREATE TABLE `topographie1` (
  `CODE` char(1) NOT NULL default '',
  `LIBELLE` varchar(80) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `topographie2`
-- 

DROP TABLE IF EXISTS `topographie2`;
CREATE TABLE `topographie2` (
  `CODE` char(2) NOT NULL default '',
  `PERE` char(1) default NULL,
  `LIBELLE` varchar(150) default NULL,
  PRIMARY KEY  (`CODE`),
  KEY `PERE` (`PERE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `t_modetraitement`
-- 

DROP TABLE IF EXISTS `t_modetraitement`;
CREATE TABLE `t_modetraitement` (
  `CODE` char(2) NOT NULL default '',
  `DATEDEBUT` char(8) default NULL,
  `DATEFIN` char(8) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `t_association`
-- 

DROP TABLE IF EXISTS `t_association`;
CREATE TABLE `t_association` (
  `CODE` char(1) NOT NULL default '',
  `DATEDEBUT` char(8) default NULL,
  `DATEFIN` char(8) default NULL,
  `COEFFICIENT` char(4) default NULL,
  KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `t_regletarifaire`
-- 

DROP TABLE IF EXISTS `t_regletarifaire`;
CREATE TABLE `t_regletarifaire` (
  `CODE` char(1) NOT NULL default '',
  `DATEDEBUT` char(8) default NULL,
  `DATEFIN` char(8) default NULL,
  `COEFFICIENT` char(4) default NULL,
  KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `t_regroupementspecialite`
-- 

DROP TABLE IF EXISTS `t_regroupementspecialite`;
CREATE TABLE `t_regroupementspecialite` (
  `CODE` char(2) NOT NULL default '',
  `DATEDEBUT` char(8) default NULL,
  `DATEFIN` char(8) default NULL,
  `CLASSE` char(2) default NULL,
  KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `t_prestationforfait`
-- 

DROP TABLE IF EXISTS `t_prestationforfait`;
CREATE TABLE `t_prestationforfait` (
  `NATURE` char(3) NOT NULL default '',
  `DATEDEBUT` char(8) default NULL,
  `DATEFIN` char(8) default NULL,
  `TYPE` char(1) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `t_modificateurage`
-- 

DROP TABLE IF EXISTS `t_modificateurage`;
CREATE TABLE `t_modificateurage` (
  `CODE` char(1) NOT NULL default '',
  `DATEDEBUT` char(8) default NULL,
  `DATEFIN` char(8) default NULL,
  `UNITE1` char(1) default NULL,
  `AGEMIN` char(3) default NULL,
  `UNITE2` char(1) default NULL,
  `AGEMAX` char(3) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `t_seuilexotm`
-- 

DROP TABLE IF EXISTS `t_seuilexotm`;
CREATE TABLE `t_seuilexotm` (
  `DATEDEBUT` char(8) default NULL,
  `DATEFIN` char(8) default NULL,
  `METROPOLE` char(7) default NULL,
  `ANTILLES` char(7) default NULL,
  `REUNION` char(7) default NULL,
  `GUYANE` char(7) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `t_joursferies`
-- 

DROP TABLE IF EXISTS `t_joursferies`;
CREATE TABLE `t_joursferies` (
  `CAISSE` char(3) default NULL,
  `DATEDEBUT` char(8) default NULL,
  `DATEFIN` char(8) default NULL,
  `TYPE` char(1) default NULL,
  `JOURFERIE` char(8) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `t_modificateurcompat`
-- 

DROP TABLE IF EXISTS `t_modificateurcompat`;
CREATE TABLE `t_modificateurcompat` (
  `CODE1` char(1) NOT NULL,
  `CODE2` char(1) NOT NULL,
  `DATEDEBUT` varchar(8) NOT NULL default '00000000',
  `DATEFIN` varchar(8) NOT NULL default '00000000',
  KEY `CODE1` (`CODE1`),
  KEY `CODE2` (`CODE2`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `t_modificateurcoherence`
-- 

DROP TABLE IF EXISTS `t_modificateurcoherence`;
CREATE TABLE `t_modificateurcoherence` (
  `CODE` char(1) NOT NULL default '',
  `DATEDEBUT` char(8) default NULL,
  `DATEFIN` char(8) default NULL,
  `CONTROLECOHERENCE` char(1) default NULL,
  `PRESENCEMULTIPLE` char(1) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `t_modificateurforfait`
-- 

DROP TABLE IF EXISTS `t_modificateurforfait`;
CREATE TABLE `t_modificateurforfait` (
  `CODE` char(1) NOT NULL,
  `DATEDEBUT` varchar(8) NOT NULL,
  `DATEFIN` varchar(8) NOT NULL,
  `FORFAIT` varchar(7) NOT NULL,
  `COEFFICIENT` varchar(4) NOT NULL,
  KEY `CODE` (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `t_rembtnonconventionnes`
-- 

DROP TABLE IF EXISTS `t_rembtnonconventionnes`;
CREATE TABLE `t_rembtnonconventionnes` (
  `DATEDEBUT` char(8) default NULL,
  `DATEFIN` char(8) default NULL,
  `FORFAIT` char(7) default NULL,
  `COEFFICIENT` char(4) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `t_natureprestation`
-- 

DROP TABLE IF EXISTS `t_natureprestation`;
CREATE TABLE `t_natureprestation` (
  `CODE` char(3) NOT NULL default '',
  `DATEDEBUT` char(8) default NULL,
  `DATEFIN` char(8) default NULL,
  `LETTRECLE` char(1) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `t_disciplinetarifaire`
-- 

DROP TABLE IF EXISTS `t_disciplinetarifaire`;
CREATE TABLE `t_disciplinetarifaire` (
  `CODE` char(3) NOT NULL default '',
  `DATEDEBUT` char(8) default NULL,
  `DATEFIN` char(8) default NULL,
  `CLASSE` char(2) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `t_modificateurinfooc`
-- 

DROP TABLE IF EXISTS `t_modificateurinfooc`;
CREATE TABLE `t_modificateurinfooc` (
  `CODE` char(1) NOT NULL default '',
  `DATEDEBUT` char(8) default NULL,
  `DATEFIN` char(8) default NULL,
  `CODEOC` char(1) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `t_ccamprestationngap`
-- 

DROP TABLE IF EXISTS `t_ccamprestationngap`;
CREATE TABLE `t_ccamprestationngap` (
  `CODE` char(3) NOT NULL default '',
  `SPECIALITE` char(2) default NULL,
  `DATEOBLIGATION` char(8) default NULL,
  KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `t_localisationdents`
-- 

DROP TABLE IF EXISTS `t_localisationdents`;
CREATE TABLE `t_localisationdents` (
  `DATEDEBUT` char(8) default NULL,
  `DATEFIN` char(8) default NULL,
  `LOCDENT` int(2) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `t_modificateurnombre`
-- 

DROP TABLE IF EXISTS `t_modificateurnombre`;
CREATE TABLE `t_modificateurnombre` (
  `DATEDEBUT` varchar(8) NOT NULL,
  `DATEFIN` varchar(8) NOT NULL,
  `NOMBRE` tinyint(4) NOT NULL,
  KEY `DATEDEBUT` (`DATEDEBUT`),
  KEY `DATEFIN` (`DATEFIN`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `t_conceptsdivers`
-- 

DROP TABLE IF EXISTS `t_conceptsdivers`;
CREATE TABLE `t_conceptsdivers` (
  `CODE` char(2) NOT NULL default '',
  `DATEDEBUT` char(8) default NULL,
  `DATEFIN` char(8) default NULL,
  `CONCEPT` varchar(10) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_typenote`
-- 

DROP TABLE IF EXISTS `c_typenote`;
CREATE TABLE `c_typenote` (
  `CODE` char(2) NOT NULL default '',
  `LIBELLE` varchar(100) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_conditionsgenerales`
-- 

DROP TABLE IF EXISTS `c_conditionsgenerales`;
CREATE TABLE `c_conditionsgenerales` (
  `CODE` char(4) NOT NULL default '',
  `LIBELLE` varchar(100) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_classedmt`
-- 

DROP TABLE IF EXISTS `c_classedmt`;
CREATE TABLE `c_classedmt` (
  `CODE` char(2) NOT NULL default '',
  `LIBELLE` varchar(100) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_exotm`
-- 

DROP TABLE IF EXISTS `c_exotm`;
CREATE TABLE `c_exotm` (
  `CODE` char(1) NOT NULL default '',
  `LIBELLE` varchar(80) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_natureassurance`
-- 

DROP TABLE IF EXISTS `c_natureassurance`;
CREATE TABLE `c_natureassurance` (
  `CODE` char(2) NOT NULL default '',
  `LIBELLE` varchar(100) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_remboursement`
-- 

DROP TABLE IF EXISTS `c_remboursement`;
CREATE TABLE `c_remboursement` (
  `CODE` char(1) NOT NULL default '',
  `LIBELLE` varchar(80) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_fraisdeplacement`
-- 

DROP TABLE IF EXISTS `c_fraisdeplacement`;
CREATE TABLE `c_fraisdeplacement` (
  `CODE` char(1) NOT NULL default '',
  `LIBELLE` varchar(80) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_typeacte`
-- 

DROP TABLE IF EXISTS `c_typeacte`;
CREATE TABLE `c_typeacte` (
  `CODE` char(1) NOT NULL default '',
  `LIBELLE` varchar(80) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_typeforfait`
-- 

DROP TABLE IF EXISTS `c_typeforfait`;
CREATE TABLE `c_typeforfait` (
  `CODE` char(1) NOT NULL default '',
  `LIBELLE` varchar(100) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_extensiondoc`
-- 

DROP TABLE IF EXISTS `c_extensiondoc`;
CREATE TABLE `c_extensiondoc` (
  `CODE` char(1) NOT NULL default '',
  `LIBELLE` varchar(100) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_activite`
-- 

DROP TABLE IF EXISTS `c_activite`;
CREATE TABLE `c_activite` (
  `CODE` char(1) NOT NULL default '',
  `LIBELLE` varchar(100) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_categoriemedicale`
-- 

DROP TABLE IF EXISTS `c_categoriemedicale`;
CREATE TABLE `c_categoriemedicale` (
  `CODE` char(2) NOT NULL default '',
  `LIBELLE` varchar(100) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_coderegroupement`
-- 

DROP TABLE IF EXISTS `c_coderegroupement`;
CREATE TABLE `c_coderegroupement` (
  `CODE` char(3) NOT NULL default '',
  `LIBELLE` varchar(100) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_categoriespecialite`
-- 

DROP TABLE IF EXISTS `c_categoriespecialite`;
CREATE TABLE `c_categoriespecialite` (
  `CODE` char(2) NOT NULL default '',
  `LIBELLE` varchar(100) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_paiementseances`
-- 

DROP TABLE IF EXISTS `c_paiementseances`;
CREATE TABLE `c_paiementseances` (
  `CODE` char(1) NOT NULL default '',
  `LIBELLE` varchar(80) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_phase`
-- 

DROP TABLE IF EXISTS `c_phase`;
CREATE TABLE `c_phase` (
  `CODE` char(1) NOT NULL default '',
  `LIBELLE` varchar(80) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_dentsincomp`
-- 

DROP TABLE IF EXISTS `c_dentsincomp`;
CREATE TABLE `c_dentsincomp` (
  `CODE` char(2) NOT NULL default '',
  `LIBELLE` varchar(80) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_caisseoutremer`
-- 

DROP TABLE IF EXISTS `c_caisseoutremer`;
CREATE TABLE `c_caisseoutremer` (
  `CODE` char(3) NOT NULL default '',
  `LIBELLE` varchar(50) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `l_anp`
-- 

DROP TABLE IF EXISTS `l_anp`;
CREATE TABLE `l_anp` (
  `CODE` char(1) NOT NULL default '',
  `LIBELLE` varchar(100) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `l_regletarifaire`
-- 

DROP TABLE IF EXISTS `l_regletarifaire`;
CREATE TABLE `l_regletarifaire` (
  `CODE` char(1) NOT NULL default '',
  `LIBELLE` varchar(100) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `l_specialite`
-- 

DROP TABLE IF EXISTS `l_specialite`;
CREATE TABLE `l_specialite` (
  `CODE` char(2) NOT NULL default '',
  `LIBELLE` varchar(100) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `l_modificateur`
-- 

DROP TABLE IF EXISTS `l_modificateur`;
CREATE TABLE `l_modificateur` (
  `CODE` char(1) NOT NULL default '',
  `LIBELLE` varchar(100) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `l_dmt`
-- 

DROP TABLE IF EXISTS `l_dmt`;
CREATE TABLE `l_dmt` (
  `CODE` char(3) NOT NULL default '',
  `LIBELLE` varchar(100) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_compatexotm`
-- 

DROP TABLE IF EXISTS `c_compatexotm`;
CREATE TABLE `c_compatexotm` (
  `CODE1` char(1) NOT NULL default '',
  `CODE2` char(1) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_arborescence`
-- 

DROP TABLE IF EXISTS `c_arborescence`;
CREATE TABLE `c_arborescence` (
  `CODEMENU` varchar(6) NOT NULL default '',
  `CODEPERE` varchar(6) default NULL,
  `RANG` varchar(6) default NULL,
  `LIBELLE` text,
  PRIMARY KEY  (`CODEMENU`),
  KEY `CODEPERE` (`CODEPERE`),
  KEY `RANG` (`RANG`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_notesarborescence`
-- 

DROP TABLE IF EXISTS `c_notesarborescence`;
CREATE TABLE `c_notesarborescence` (
  `CODEMENU` varchar(6) default NULL,
  `TYPE` char(2) default NULL,
  `TEXTE` text,
  KEY `CODEMENU` (`CODEMENU`),
  KEY `TYPE` (`TYPE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `c_uniteoeuvre`
-- 

DROP TABLE IF EXISTS `c_uniteoeuvre`;
CREATE TABLE `c_uniteoeuvre` (
  `CODE` char(3) NOT NULL default '',
  `DATEEFFET` char(8) default NULL,
  `VALEUR` char(6)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `g_listemots`
-- 

DROP TABLE IF EXISTS `g_listemots`;
CREATE TABLE `g_listemots` (
  `MOT` varchar(50) default NULL,
  `DEFINITION` varchar(50) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `p_acte`
-- 

DROP TABLE IF EXISTS `p_acte`;
CREATE TABLE `p_acte` (
  `CODE` varchar(13) NOT NULL default '',
  `LIBELLECOURT` varchar(70) default NULL,
  `TYPE` char(1) default NULL,
  `SEXE` char(1) default NULL,
  `DATECREATION` char(8) default NULL,
  `DATEFIN` char(8) default NULL,
  `ASSURANCE1` char(2) default NULL,
  `ASSURANCE2` char(2) default NULL,
  `ASSURANCE3` char(2) default NULL,
  `ASSURANCE4` char(2) default NULL,
  `ASSURANCE5` char(2) default NULL,
  `ASSURANCE6` char(2) default NULL,
  `ASSURANCE7` char(2) default NULL,
  `ASSURANCE8` char(2) default NULL,
  `ASSURANCE9` char(2) default NULL,
  `ASSURANCE10` char(2) default NULL,
  `DEPLACEMENT` char(1) default NULL,
  `ARBORESCENCE1` varchar(6) default NULL,
  `ARBORESCENCE2` varchar(6) default NULL,
  `ARBORESCENCE3` varchar(6) default NULL,
  `ARBORESCENCE4` varchar(6) default NULL,
  `ARBORESCENCE5` varchar(6) default NULL,
  `ARBORESCENCE6` varchar(6) default NULL,
  `ARBORESCENCE7` varchar(6) default NULL,
  `ARBORESCENCE8` varchar(6) default NULL,
  `ARBORESCENCE9` varchar(6) default NULL,
  `ARBORESCENCE10` varchar(6) default NULL,
  `PLACEARBORESCENCE` varchar(12) default NULL,
  `CODESTRUCTURE` varchar(13) default NULL,
  `CODEPRECEDENT` varchar(13) default NULL,
  `CODESUIVANT` varchar(13) default NULL,
  `LIBELLELONG` text,
  PRIMARY KEY  (`CODE`),
  KEY `ARBORESCENCE1` (`ARBORESCENCE1`),
  KEY `ARBORESCENCE2` (`ARBORESCENCE2`),
  KEY `ARBORESCENCE3` (`ARBORESCENCE3`),
  KEY `ARBORESCENCE4` (`ARBORESCENCE4`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `p_acte_infotarif`
-- 

DROP TABLE IF EXISTS `p_acte_infotarif`;
CREATE TABLE `p_acte_infotarif` (
  `CODEACTE` char(13) default NULL,
  `DATEEFFET` char(8) default NULL,
  `DATEARRETE` char(8) default NULL,
  `DATEPUBLICATION` char(8) default NULL,
  `REMBOURSEMENT` char(1) default NULL,
  `ENTENTE` char(1) default NULL,
  `EXOTICKET1` char(1) default NULL,
  `EXOTICKET2` char(1) default NULL,
  `EXOTICKET3` char(1) default NULL,
  `EXOTICKET4` char(1) default NULL,
  `EXOTICKET5` char(1) default NULL,
  `PRESCRIPTEUR1` char(2) default NULL,
  `PRESCRIPTEUR2` char(2) default NULL,
  `PRESCRIPTEUR3` char(2) default NULL,
  `PRESCRIPTEUR4` char(2) default NULL,
  `PRESCRIPTEUR5` char(2) default NULL,
  `PRESCRIPTEUR6` char(2) default NULL,
  `PRESCRIPTEUR7` char(2) default NULL,
  `PRESCRIPTEUR8` char(2) default NULL,
  `PRESCRIPTEUR9` char(2) default NULL,
  `PRESCRIPTEUR10` char(2) default NULL,
  `FORFAIT1` char(1) default NULL,
  `FORFAIT2` char(1) default NULL,
  `FORFAIT3` char(1) default NULL,
  `FORFAIT4` char(1) default NULL,
  `FORFAIT5` char(1) default NULL,
  `FORFAIT6` char(1) default NULL,
  `FORFAIT7` char(1) default NULL,
  `FORFAIT8` char(1) default NULL,
  `FORFAIT9` char(1) default NULL,
  `FORFAIT10` char(1) default NULL,
  KEY `CODEACTE` (`CODEACTE`),
  KEY `REMBOURSEMENT` (`REMBOURSEMENT`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `p_acte_procedure`
-- 

DROP TABLE IF EXISTS `p_acte_procedure`;
CREATE TABLE `p_acte_procedure` (
  `CODEACTE` char(13) default NULL,
  `DATEEFFET` char(8) default NULL,
  `CODEPROCEDURE` char(13) default NULL,
  KEY `CODEACTE` (`CODEACTE`),
  KEY `CODEPROCEDURE` (`CODEPROCEDURE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `p_acte_incompatibilite`
-- 

DROP TABLE IF EXISTS `p_acte_incompatibilite`;
CREATE TABLE `p_acte_incompatibilite` (
  `CODEACTE` char(13) default NULL,
  `DATEEFFET` char(8) default NULL,
  `INCOMPATIBLE` char(13) default NULL,
  KEY `CODEACTE` (`CODEACTE`),
  KEY `INCOMPATIBLE` (`INCOMPATIBLE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `p_activite`
-- 

DROP TABLE IF EXISTS `p_activite`;
CREATE TABLE `p_activite` (
  `CODEACTE` char(13) default NULL,
  `ACTIVITE` char(1) default NULL,
  KEY `CODEACTE` (`CODEACTE`),
  KEY `ACTIVITE` (`ACTIVITE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `p_activite_classif`
-- 

DROP TABLE IF EXISTS `p_activite_classif`;
CREATE TABLE `p_activite_classif` (
  `CODEACTE` char(13) default NULL,
  `ACTIVITE` char(1) default NULL,
  `DATEEFFET` char(8) default NULL,
  `DATEARRETE` char(8) default NULL,
  `DATEPUBJO` char(8) default NULL,
  `CATMED` char(2) default NULL,
  `REGROUP` char(3) default NULL,
  KEY `CODEACTE` (`CODEACTE`),
  KEY `ACTIVITE` (`ACTIVITE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `p_activite_associabilite`
-- 

DROP TABLE IF EXISTS `p_activite_associabilite`;
CREATE TABLE `p_activite_associabilite` (
  `CODEACTE` char(13) default NULL,
  `ACTIVITE` char(1) default NULL,
  `DATEEFFET` char(8) default NULL,
  `ACTEASSO` char(13) default NULL,
  `ACTIVITEASSO` char(1) default NULL,
  `REGLE` char(1) default NULL,
  KEY `CODEACTE` (`CODEACTE`),
  KEY `ACTIVITE` (`ACTIVITE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `p_phase`
-- 

DROP TABLE IF EXISTS `p_phase`;
CREATE TABLE `p_phase` (
  `CODEACTE` char(13) default NULL,
  `ACTIVITE` char(1) default NULL,
  `PHASE` char(1) default NULL,
  `NBDENTS` char(2) default NULL,
  `AGEMIN` char(3) default NULL,
  `AGEMAX` char(3) default NULL,
  `ICR` char(4) default NULL,
  `CLASSANT` char(1) default NULL,
  KEY `CODEACTE` (`CODEACTE`),
  KEY `ACTIVITE` (`ACTIVITE`),
  KEY `PHASE` (`ACTIVITE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `p_phase_acte`
-- 

DROP TABLE IF EXISTS `p_phase_acte`;
CREATE TABLE `p_phase_acte` (
  `CODEACTE` char(13) NOT NULL default '',
  `ACTIVITE` char(1) NOT NULL default '',
  `PHASE` char(1) NOT NULL default '',
  `DATEEFFET` char(8) default NULL,
  `DATEARRETE` char(8) default NULL,
  `DATEPUBJO` char(8) default NULL,
  `NBSEANCES` char(2) default NULL,
  `UNITEOEUVRE` char(3) default NULL,
  `COEFFUOEUVRE` varchar(6) default NULL,
  `CODEPAIEMENT` char(1) default NULL,
  `PRIXUNITAIRE` varchar(6) default NULL,
  `PRIXUNITAIRE2` varchar(6) default NULL,
  `COEFFDOM1` varchar(4) default NULL,
  `COEFFDOM2` varchar(4) default NULL,
  `COEFFDOM3` varchar(4) default NULL,
  `COEFFDOM4` varchar(4) default NULL,
  `CHARGESCAB` varchar(6) default NULL,
  KEY `CODEACTE` (`CODEACTE`),
  KEY `ACTIVITE` (`ACTIVITE`),
  KEY `PHASE` (`PHASE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `p_phase_acte_comp`
-- 

DROP TABLE IF EXISTS `p_phase_acte_comp`;
CREATE TABLE `p_phase_acte_comp` (
  `CODEACTE` char(13) NOT NULL default '',
  `ACTIVITE` char(1) NOT NULL default '',
  `PHASE` char(1) NOT NULL default '',
  `DATEEFFET` char(8) default NULL,
  `SCORETRAVMED` varchar(6) default NULL,
  `COUTPRATIQUE` varchar(6) default NULL,
  KEY `CODEACTE` (`CODEACTE`),
  KEY `ACTIVITE` (`ACTIVITE`),
  KEY `PHASE` (`PHASE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `p_activite_modificateur`
-- 

DROP TABLE IF EXISTS `p_activite_modificateur`;
CREATE TABLE `p_activite_modificateur` (
  `CODEACTE` char(13) default NULL,
  `CODEACTIVITE` char(1) default NULL,
  `DATEEFFET` char(8) default NULL,
  `MODIFICATEUR` char(1) default NULL,
  KEY `CODEACTE` (`CODEACTE`),
  KEY `CODEACTIVITE` (`CODEACTIVITE`),
  KEY `MODIFICATEUR` (`MODIFICATEUR`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `p_acte_notes`
-- 

DROP TABLE IF EXISTS `p_acte_notes`;
CREATE TABLE `p_acte_notes` (
  `CODEACTE` char(13) default NULL,
  `TYPE` char(2) default NULL,
  `TEXTE` text,
  KEY `CODEACTE` (`CODEACTE`),
  KEY `TYPE` (`TYPE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `p_acte_typeforfait`
-- 

DROP TABLE IF EXISTS `p_acte_typeforfait`;
CREATE TABLE `p_acte_typeforfait` (
  `CODEACTE` char(13) default NULL,
  `DATEEFFET` char(8) default NULL,
  `TYPE` char(1) default NULL,
  KEY `CODEACTE` (`CODEACTE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `p_phase_dentsincomp`
-- 

DROP TABLE IF EXISTS `p_phase_dentsincomp`;
CREATE TABLE `p_phase_dentsincomp` (
  `CODEACTE` char(13) NOT NULL default '',
  `ACTIVITE` char(1) NOT NULL default '',
  `PHASE` char(1) NOT NULL default '',
  `LOCDENT` char(2) default NULL,
  KEY `CODEACTE` (`CODEACTE`),
  KEY `ACTIVITE` (`ACTIVITE`),
  KEY `PHASE` (`PHASE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
