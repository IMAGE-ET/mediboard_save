<?php
$locales['module-[SAMPLE]-court'] = '[SAMPLE]';
$locales['module-[SAMPLE]-long'] = '[SAMPLE]';
?>