<?php /* $Id: $ */

/**
 *	@package Mediboard
 *	@subpackage dPmateriel
 *	@version $Revision: $
 *  @author S�bastien Fillonneau
 */

require_once($AppUI->getSystemClass("tabindex"));

$tabs = array();
$tabs[] = array("idx_stock", "Consulter les stocks", 0);
$tabs[] = array("vw_edit_stock", "Cr�er / Modifier un stock", 1);
$tabs[] = array("idx_materiel", "Consulter les fiches mat�riel", 0);
$tabs[] = array("vw_edit_materiel", "Cr�er / Modifier une fiche", 1);
$default = 0;

$index = new CTabIndex($tabs, $default);
$index->show();

?>