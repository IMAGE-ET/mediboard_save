<root>
<name><?php echo text::xmlData($name) ?></name>
</root>
