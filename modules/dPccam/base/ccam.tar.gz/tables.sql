-- phpMyAdmin SQL Dump
-- version 2.9.2-rc1
-- http://www.phpmyadmin.net
-- 
-- Serveur: localhost
-- G�n�r� le : Mardi 16 Octobre 2007 � 10:32
-- Version du serveur: 5.0.27
-- Version de PHP: 5.2.0
-- 
-- Base de donn�es: `ccamV2`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `acces1`
-- 

DROP TABLE IF EXISTS `acces1`;
CREATE TABLE `acces1` (
  `CODE` char(1) NOT NULL default '',
  `ACCES` varchar(80) default NULL,
  `LIBELLE` varchar(255) default NULL,
  PRIMARY KEY  (`CODE`),
  KEY `ACCES` (`ACCES`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `acces2`
-- 

DROP TABLE IF EXISTS `acces2`;
CREATE TABLE `acces2` (
  `PERE` char(1) default NULL,
  `LIBELLE` varchar(150) default NULL,
  KEY `PERE` (`PERE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `actes`
-- 

DROP TABLE IF EXISTS `actes`;
CREATE TABLE `actes` (
  `CODE` varchar(13) NOT NULL default '',
  `LIBELLECOURT` varchar(70) default NULL,
  `TYPE` char(1) default NULL,
  `SEXE` char(1) default NULL,
  `DATECREATION` varchar(8) default NULL,
  `DATEFIN` varchar(8) default NULL,
  `ASSURANCE1` char(2) default NULL,
  `ASSURANCE2` char(2) default NULL,
  `ASSURANCE3` char(2) default NULL,
  `ASSURANCE4` char(2) default NULL,
  `ASSURANCE5` char(2) default NULL,
  `ASSURANCE6` char(2) default NULL,
  `ASSURANCE7` char(2) default NULL,
  `ASSURANCE8` char(2) default NULL,
  `ASSURANCE9` char(2) default NULL,
  `ASSURANCE10` char(2) default NULL,
  `DEPLACEMENT` char(1) default NULL,
  `ARBORESCENCE1` varchar(6) default NULL,
  `ARBORESCENCE2` varchar(6) default NULL,
  `ARBORESCENCE3` varchar(6) default NULL,
  `ARBORESCENCE4` varchar(6) default NULL,
  `ARBORESCENCE5` varchar(6) default NULL,
  `ARBORESCENCE6` varchar(6) default NULL,
  `ARBORESCENCE7` varchar(6) default NULL,
  `ARBORESCENCE8` varchar(6) default NULL,
  `ARBORESCENCE9` varchar(6) default NULL,
  `ARBORESCENCE10` varchar(6) default NULL,
  `PLACEARBORESCENCE` varchar(12) default NULL,
  `CODESTRUCTURE` varchar(13) default NULL,
  `CODEPRECEDENT` varchar(13) default NULL,
  `CODESUIVANT` varchar(13) default NULL,
  `LIBELLELONG` text,
  PRIMARY KEY  (`CODE`),
  KEY `ARBORESCENCE1` (`ARBORESCENCE1`),
  KEY `ARBORESCENCE2` (`ARBORESCENCE2`),
  KEY `ARBORESCENCE3` (`ARBORESCENCE3`),
  KEY `ARBORESCENCE4` (`ARBORESCENCE4`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `action1`
-- 

DROP TABLE IF EXISTS `action1`;
CREATE TABLE `action1` (
  `VERBE` varchar(20) NOT NULL default '',
  `CODE` char(1) default NULL,
  `LIBELLE` varchar(255) default NULL,
  PRIMARY KEY  (`VERBE`),
  KEY `CODE` (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `action2`
-- 

DROP TABLE IF EXISTS `action2`;
CREATE TABLE `action2` (
  `VERBE` varchar(30) default NULL,
  `CODE` char(1) default NULL,
  `SUBSTANTIF` varchar(20) default NULL,
  KEY `ACTION` (`VERBE`),
  KEY `CODE` (`CODE`),
  KEY `VERBE` (`SUBSTANTIF`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `activite`
-- 

DROP TABLE IF EXISTS `activite`;
CREATE TABLE `activite` (
  `CODE` char(1) NOT NULL default '',
  `LIBELLE` varchar(100) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `activiteacte`
-- 

DROP TABLE IF EXISTS `activiteacte`;
CREATE TABLE `activiteacte` (
  `CODEACTE` char(13) default NULL,
  `ACTIVITE` char(1) default NULL,
  KEY `CODEACTE` (`CODEACTE`),
  KEY `ACTIVITE` (`ACTIVITE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `arborescence`
-- 

DROP TABLE IF EXISTS `arborescence`;
CREATE TABLE `arborescence` (
  `CODEMENU` varchar(6) NOT NULL default '',
  `CODEPERE` varchar(6) default NULL,
  `RANG` varchar(6) default NULL,
  `LIBELLE` text,
  PRIMARY KEY  (`CODEMENU`),
  KEY `CODEPERE` (`CODEPERE`),
  KEY `RANG` (`RANG`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `associabilite`
-- 

DROP TABLE IF EXISTS `associabilite`;
CREATE TABLE `associabilite` (
  `CODEACTE` char(13) default NULL,
  `ACTIVITE` char(1) default NULL,
  `DATEEFFET` char(8) default NULL,
  `ACTEASSO` char(13) default NULL,
  `ACTIVITEASSO` char(1) default NULL,
  `REGLE` char(1) default NULL,
  KEY `CODEACTE` (`CODEACTE`),
  KEY `ACTIVITE` (`ACTIVITE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `association`
-- 

DROP TABLE IF EXISTS `association`;
CREATE TABLE `association` (
  `CODE` char(1) NOT NULL default '',
  `DATEDEBUT` char(8) default NULL,
  `DATEFIN` char(8) default NULL,
  `COEFFICIENT` char(4) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `incompatibilite`
-- 

DROP TABLE IF EXISTS `incompatibilite`;
CREATE TABLE `incompatibilite` (
  `CODEACTE` char(13) default NULL,
  `DATEEFFET` char(8) default NULL,
  `INCOMPATIBLE` char(13) default NULL,
  KEY `CODEACTE` (`CODEACTE`),
  KEY `INCOMPATIBLE` (`INCOMPATIBLE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `modificateur`
-- 

DROP TABLE IF EXISTS `modificateur`;
CREATE TABLE `modificateur` (
  `CODE` char(1) NOT NULL default '',
  `LIBELLE` varchar(100) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `modificateuracte`
-- 

DROP TABLE IF EXISTS `modificateuracte`;
CREATE TABLE `modificateuracte` (
  `CODEACTE` varchar(13) default NULL,
  `CODEACTIVITE` char(1) default NULL,
  `DATEEFFET` varchar(8) default NULL,
  `MODIFICATEUR` char(1) default NULL,
  KEY `CODEACTE` (`CODEACTE`),
  KEY `CODEACTIVITE` (`CODEACTIVITE`),
  KEY `MODIFICATEUR` (`MODIFICATEUR`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `modificateurcompat`
-- 

DROP TABLE IF EXISTS `modificateurcompat`;
CREATE TABLE `modificateurcompat` (
  `CODE1` char(1) NOT NULL,
  `CODE2` char(1) NOT NULL,
  `DATEDEBUT` varchar(8) NOT NULL default '00000000',
  `DATEFIN` varchar(8) NOT NULL default '00000000',
  KEY `CODE1` (`CODE1`),
  KEY `CODE2` (`CODE2`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `modificateurforfait`
-- 

DROP TABLE IF EXISTS `modificateurforfait`;
CREATE TABLE `modificateurforfait` (
  `CODE` char(1) NOT NULL,
  `DATEDEBUT` varchar(8) NOT NULL,
  `DATEFIN` varchar(8) NOT NULL,
  `FORFAIT` varchar(7) NOT NULL,
  `COEFFICIENT` varchar(4) NOT NULL,
  KEY `CODE` (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `modificateurnombre`
-- 

DROP TABLE IF EXISTS `modificateurnombre`;
CREATE TABLE `modificateurnombre` (
  `DATEDEBUT` varchar(8) NOT NULL,
  `DATEFIN` varchar(8) NOT NULL,
  `NOMBRE` tinyint(4) NOT NULL,
  KEY `DATEDEBUT` (`DATEDEBUT`),
  KEY `DATEFIN` (`DATEFIN`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `motcle`
-- 

DROP TABLE IF EXISTS `motcle`;
CREATE TABLE `motcle` (
  `mtcle` varchar(40) NOT NULL default '',
  `codacc` varchar(13) NOT NULL default '',
  `phonmtcle` varchar(40) default NULL,
  `syn` varchar(40) default NULL,
  KEY `mtcle` (`mtcle`),
  KEY `codacc` (`codacc`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `notes`
-- 

DROP TABLE IF EXISTS `notes`;
CREATE TABLE `notes` (
  `CODEACTE` varchar(13) default NULL,
  `TYPE` char(2) default NULL,
  `TEXTE` text,
  KEY `CODEACTE` (`CODEACTE`),
  KEY `TYPE` (`TYPE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `notesarborescence`
-- 

DROP TABLE IF EXISTS `notesarborescence`;
CREATE TABLE `notesarborescence` (
  `CODEMENU` varchar(6) default NULL,
  `TYPE` char(2) default NULL,
  `TEXTE` text,
  KEY `CODEMENU` (`CODEMENU`),
  KEY `TYPE` (`TYPE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `phase`
-- 

DROP TABLE IF EXISTS `phase`;
CREATE TABLE `phase` (
  `CODE` char(1) NOT NULL default '',
  `LIBELLE` varchar(80) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `phaseacte`
-- 

DROP TABLE IF EXISTS `phaseacte`;
CREATE TABLE `phaseacte` (
  `CODEACTE` varchar(13) NOT NULL default '',
  `ACTIVITE` char(1) NOT NULL default '',
  `PHASE` char(1) NOT NULL default '',
  `DATE1` varchar(8) default NULL,
  `DATE2` varchar(8) default NULL,
  `DATE3` varchar(8) default NULL,
  `NBSEANCES` char(2) default NULL,
  `UNITEOEUVRE` char(3) default NULL,
  `COEFFUOEUVRE` varchar(6) default NULL,
  `CODEPAIEMENT` char(1) default NULL,
  `PRIXUNITAIRE` varchar(6) default NULL,
  `COEFFDOM1` varchar(4) default NULL,
  `COEFFDOM2` varchar(4) default NULL,
  `COEFFDOM3` varchar(4) default NULL,
  `COEFFDOM4` varchar(4) default NULL,
  `CHARGESCAB` varchar(6) default NULL,
  KEY `CODEACTE` (`CODEACTE`),
  KEY `ACTIVITE` (`ACTIVITE`),
  KEY `PHASE` (`PHASE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `procedures`
-- 

DROP TABLE IF EXISTS `procedures`;
CREATE TABLE `procedures` (
  `CODEACTE` char(13) default NULL,
  `DATEEFFET` char(8) default NULL,
  `CODEPROCEDURE` char(13) default NULL,
  KEY `CODEACTE` (`CODEACTE`),
  KEY `CODEPROCEDURE` (`CODEPROCEDURE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `synonymes`
-- 

DROP TABLE IF EXISTS `synonymes`;
CREATE TABLE `synonymes` (
  `MOT` varchar(30) NOT NULL default '',
  `SYNONYME` varchar(30) NOT NULL default '',
  KEY `MOT` (`MOT`),
  KEY `SYNONYME` (`SYNONYME`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `topographie1`
-- 

DROP TABLE IF EXISTS `topographie1`;
CREATE TABLE `topographie1` (
  `CODE` char(1) NOT NULL default '',
  `LIBELLE` varchar(80) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `topographie2`
-- 

DROP TABLE IF EXISTS `topographie2`;
CREATE TABLE `topographie2` (
  `CODE` char(2) NOT NULL default '',
  `PERE` char(1) default NULL,
  `LIBELLE` varchar(150) default NULL,
  PRIMARY KEY  (`CODE`),
  KEY `PERE` (`PERE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `typenote`
-- 

DROP TABLE IF EXISTS `typenote`;
CREATE TABLE `typenote` (
  `CODE` char(2) NOT NULL default '',
  `LIBELLE` varchar(100) default NULL,
  PRIMARY KEY  (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
