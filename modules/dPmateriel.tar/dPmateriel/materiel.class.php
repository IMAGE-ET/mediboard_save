<?php /* $Id: $ */

/**
 *	@package Mediboard
 *	@subpackage dPmateriel
 *	@version $Revision: $
 *  @author S�bastien Fillonneau
 */


require_once( $AppUI->getSystemClass('mbobject'));
require_once( $AppUI->getModuleClass("dPmateriel", "stock") );

/**
 * The CMateriel class
 */
class CMateriel extends CMbObject {
  // DB Table key
	var $materiel_id = null;
	
  // DB Fields
  var $nom = null;
  var $code_barre = null;
  var $description = null;

  // Object References
  var $_ref_stock = null;
  
	function CMateriel() {
      $this->CMbObject( 'materiel', 'materiel_id' );

      $this->_props["nom"] = "str|maxLength|50|notNull";
      $this->_props["code_barre"] = "num";
      $this->_props["description"] = "str";
	}
	
	function LoadRefsBack(){
	  $this->_ref_stock = new CStock;
	  $where = array();
	  $where["materiel_id"] = "= '$this->materiel_id'";
      $this->_ref_stock = $this->_ref_stock->loadList($where);
      foreach($this->_ref_stock as $key => $value) {
        $this->_ref_stock[$key]->loadRefsFwd();
        $this->_ref_stock[$key]->_ref_group->loadRefsFwd();
      }
	} 
	
	function canDelete(&$msg, $oid = null) {
    $tables[] = array (
      'label' => 'Stock', 
      'name' => 'stock', 
      'idfield' => 'materiel_id', 
      'joinfield' => 'materiel_id'
    );
    
    return CDpObject::canDelete( $msg, $oid, $tables );
  }
}
?>