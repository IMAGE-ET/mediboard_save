<?php /* $Id: $ */

/**
 *	@package Mediboard
 *	@subpackage dPmateriel
 *	@version $Revision: $
 *  @author S�bastien Fillonneau
 */
 
global $AppUI, $canRead, $canEdit, $m;

if (!$canRead) {
	$AppUI->redirect( "m=system&a=access_denied" );
}
 
require_once( $AppUI->getModuleClass("dPmateriel", "materiel") );

$materiel = new CMateriel;
$where = array();
$listMateriel = $materiel->loadList($where);

// Cr�ation du template
require_once( $AppUI->getSystemClass("smartydp"));
$smarty = new CSmartyDP;

$smarty->assign("listMateriel", $listMateriel);

$smarty->display('idx_materiel.tpl');

?>