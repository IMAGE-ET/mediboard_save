<?php

namespace Elastica\Aggregation;

/**
 * Class Sum
 * @package Elastica\Aggregation
 * @link http://www.elasticsearch.org/guide/en/elasticsearch/reference/master/search-aggregations-metrics-sum-aggregation.html
 */
class Sum extends AbstractSimpleAggregation
{

} 