<?php 
/**
 * $Id$
 * 
 * @package    Mediboard
 * @subpackage {NAME_CANONICAL}
 * @author     SARL OpenXtrem <dev@openxtrem.com>
 * @license    {LICENSE}
 * @version    $Revision$
 */

CCanDo::checkAdmin();

$smarty = new CSmartyDP();

//$smarty->assign('var', $states);

$smarty->display("configure.tpl");
