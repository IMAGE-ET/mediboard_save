<?php

namespace Elastica\Aggregation;

/**
 * Class ExtendedStats
 * @package Elastica\Aggregation
 * @link http://www.elasticsearch.org/guide/en/elasticsearch/reference/master/search-aggregations-metrics-extendedstats-aggregation.html
 */
class ExtendedStats extends AbstractSimpleAggregation
{

} 