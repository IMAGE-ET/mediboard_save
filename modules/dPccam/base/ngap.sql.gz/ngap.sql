-- Licenced under GNU GPL
-- @package Medibaord
-- @module dPccam
-- @author Thomas Despoix

/* Query 
  SELECT
    DISTINCT `S_NOM_CODE` AS CODE, 
    `S_NOM_LIBELLE` AS LIBELLE, 
    `S_NOM_LETTRE_CLE` AS LETTRE_CLE, 
    `S_NOM_TARIF_2` AS TARIF
    FROM `s_f_nomenclature`
*/

-- 
-- Structure de la table `codes_ngap`
-- 

DROP TABLE `codes_ngap`;

CREATE TABLE `codes_ngap` (
  `code` varchar(10) default NULL,
  `libelle` varchar(50) default NULL,
  `lettre_cle` tinyint(3) unsigned default NULL,
  `tarif` double default NULL,
  KEY `code` (`code`),
  KEY `lettre_cle` (`lettre_cle`)
);

-- 
-- Contenu de la table `codes_ngap`
-- 

INSERT INTO `s_f_nomenclature` (`S_NOM_CODE`, `S_NOM_LIBELLE`, `S_NOM_LETTRE_CLE`, `S_NOM_TARIF_2`) VALUES 
('C', 'Consultation', 1, 22),
('CA', 'Consultation approfondie', 0, 26),
('CRN', 'Majoration astreinte nuit sur la consultation', 0, 42.5),
('CRM', 'Majoration astreinte milieu de nuit sur la consult', 0, 51.5),
('CRD', 'Majoration astreinte dimanche sur la consultation', 0, 26.5),
('CST', 'Complément surveillance thermale', 0, 0),
('FPE', 'Forfait pédiatrique', 0, 5),
('HN', 'Hors nomenclature', 0, 0),
('ID', 'Indemnité de déplacement', 0, 3.5),
('IK', 'Indemnité kilométrique', 0, 0.61),
('IKM', 'Indemnité kilométrique montagne', 0, 0.91),
('IKS', 'Indemnité kilométrique spéciale', 0, 4.57),
('K', 'Acte de spécialité', 1, 1.92),
('KA', 'Acte de chirurgie d’urgence', 1, 0),
('KC', 'Acte de chirurgie (ou de chirurgie dentaire par st', 1, 2.09),
('KCC', 'Acte de chirurgie par un médecin spécialiste', 1, 2.09),
('KE', 'Acte d’échographie, échotomographie ou doppler', 1, 1.89),
('KFA', 'Forfait chirurgie KC ou KCC inférieur ou égal à 12', 1, 30.49),
('KFB', 'Forfait chirurgie KC ou KCC supérieur à 120', 1, 60.98),
('KFD', 'Forfait radiologie/echographie', 1, 0),
('KMO', 'Acte de phoniatrie par médecin', 0, 0),
('MD', 'Majoration de déplacement Critères médicaux', 0, 10),
('MDN', 'Majoration de déplacement de nuit', 0, 38.5),
('MDI', 'Majoration de déplacement de milieu de nuit', 0, 43.5),
('MDD', 'Majoration de déplacement de dimanche ou jour féri', 0, 22.6),
('MDE', 'Majoration de déplacement Critères environnementau', 0, 10),
('MM', 'Majoration de milieu de nuit ', 0, 40),
('MMD', 'Majoration pour maintien à domicile ', 0, 9.15),
('MNO', 'Majoration Nourrisson Généraliste', 0, 5),
('ORT', 'Orthopédie dentofaciale par stomatologue', 1, 2.15),
('PRO', 'Prothèse dentaire par stomatologue', 1, 2.15),
('PRA', 'Majoration d’honoraires pour produits radiopharmac', 1, 0.44),
('SCM', 'Soin conservateur par médecin', 1, 2.41),
('SES', 'Suite examen de santé', 0, 0),
('STH', 'Forfait surveillance thermale', 0, 65.03),
('TDR', 'Test de diagnostic rapide', 0, 0),
('THR', 'Demi-forfait surveillance thermale', 0, 0),
('KTH', 'Pratique médicale complémentaire en cure thermale', 0, 0),
('V', 'Visite', 1, 22),
('VA', 'Visite d’urgence', 0, 0),
('VRN', 'Majoration astreinte nuit sur la visite', 0, 46),
('VRM', 'Majoration astreinte milieu nuit sur la visite', 0, 55),
('VRD', 'Majoration astreinte dimanche sur la visite', 0, 30),
('VU', 'Visite d’urgence', 0, 0),
('Z', 'Acte de radiologie', 1, 1.33),
('ZM', 'Acte de radiologie mammographie', 0, 1.62),
('ZN', 'Acte de médecine nucléaire', 1, 1.53),
('LC', 'Consultation hors parcours', 1, 20),
('LCM', 'Soin conservateur par médecin hors parcours', 1, 2.41),
('LDD', 'Majoration de déplacement critères médicaux ou env', 0, 22.6),
('LDE', 'Majoration de déplacement Critères environnementau', 0, 10),
('LDI', 'Majoration de déplacement critères médicaux ou env', 0, 43.5),
('LDN', 'Majoration de déplacement critères médicaux ou env', 0, 35),
('LES', 'Suite examen de santé hors parcours', 0, 0),
('LFA', 'Forfait chirurgie hors parcours', 1, 0),
('LFB', 'Forfait chirurgie hors parcours', 1, 0),
('LFD', 'Forfait radiologie / échographie hors parcours', 1, 0),
('LFH', 'Forfait surveillance médicale thermale hors parcou', 0, 64.03),
('LHR', 'Demi-forfait surveillance médicale thermale hors p', 0, 0),
('LID', 'Indemnité de déplacement hors parcours', 0, 3.5),
('LK', 'Acte de spécialité hors parcours', 1, 1.92),
('LKC', 'Acte de chirurgie ou de chirurgie dentaire pour st', 1, 2.09),
('LKE', 'Echo ou doppler hors parcours', 1, 0),
('LMD', 'Majoration de déplacement Critères médicaux hors p', 0, 10),
('LMM', 'Majoration de milieu de nuit hors parcours', 0, 40),
('LMO', 'Acte de phoniatrie par médecin hors parcours', 0, 0),
('LRA', 'Majoration d''honoraires pour produit radio pharmac', 1, 0),
('LRO', 'Prothèse dentaire par stomatologue hors parcours', 1, 2.15),
('LST', 'Complément surveillance thermale hors parcours', 0, 0),
('LTH', 'Pratique médicale complémentaire en cure thermale ', 0, 0),
('LV', 'Visite hors parcours', 1, 20),
('LZ', 'Acte de radiologie hors parcours', 1, 1.33),
('LZM', 'Acte de radiologie "mammographie" hors parcours', 1, 0),
('LZN', 'Médecine nucléaire hors parcours', 1, 0),
('HCS', 'Accès libre hors coordination des soins', 0, 0),
('MTH', 'Hors résidence habituelle', 0, 0),
('MTN', 'Nouveau médecin traitant', 0, 0),
('MTO', 'Patient orienté par médecin traitant', 0, 0),
('MTR', 'Médecin traitant remplacé', 0, 0),
('MTU', 'Urgence', 0, 0),
('MCG', 'Majoration de coordination des généralistes', 0, 3),
('MU', 'Majoration d''Urgence', 0, 22.6),
('MGE', 'Majoration Généraliste Enfant', 0, 3),
('FHV', 'Forfait Honoraires de Ville', 0, 100),
('FMV', 'Forfait Médicament de Ville', 0, 91.74),
('CS', 'Consultation spécialiste', 1, 23),
('MPC', 'Majoration provisoire cliniciens', 0, 2),
('VS', 'Visite spécialiste', 1, 23),
('LCC', 'Acte spécifique des chirurgiens hors parcours', 1, 0),
('LCS', 'Consultation spécialiste hors parcours', 1, 23),
('LPC', 'Majoration provisoire cliniciens hors parcours', 0, 2),
('LVS', 'Visite spécialiste hors parcours', 1, 20.58),
('MCS', 'Majoration de coordination spécialistes', 0, 3),
('MPJ', 'Majoration Provisoire Cliniciens moins de 16 ans', 0, 5);
