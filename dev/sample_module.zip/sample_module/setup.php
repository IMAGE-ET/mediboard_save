<?php 
/**
 * $Id$
 * 
 * @package    Mediboard
 * @subpackage {NAME_CANONICAL}
 * @author     SARL OpenXtrem <dev@openxtrem.com>
 * @license    {LICENSE}
 * @version    $Revision$
 */

/**
 * {NAME_SHORT} Setup class
 */
class CSetup{NAME_CANONICAL} extends CSetup {
  /**
   * @see parent::__construct()
   */
  function __construct() {
    parent::__construct();
    
    $this->mod_name = "{NAME_CANONICAL}";
    $this->makeRevision("all");
    
    $this->mod_version = "0.01";    
  }
}
