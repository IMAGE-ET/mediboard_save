<?php /* $Id: $ */

/**
 *	@package Mediboard
 *	@subpackage dPmateriel
 *	@version $Revision: $
 *  @author S�bastien Fillonneau
 */
 
global $AppUI, $canRead, $canEdit, $m;

if (!$canRead) {
	$AppUI->redirect( "m=system&a=access_denied" );
}

require_once( $AppUI->getModuleClass("dPmateriel", "stock") );

// R�cup�ration de la liste des Stock
$stock = new CStock;
$listStock = $stock->loadList();
foreach($listStock as $key => $value) {
  $listStock[$key]->loadRefsFwd();
}

// Cr�ation du template
require_once( $AppUI->getSystemClass("smartydp"));
$smarty = new CSmartyDP;
$smarty->assign("listStock", $listStock);
$smarty->display('idx_stock.tpl');
?>
