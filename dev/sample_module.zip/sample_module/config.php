<?php 
/**
 * $Id$
 * 
 * @package    Mediboard
 * @subpackage {NAME_CANONICAL}
 * @author     SARL OpenXtrem <dev@openxtrem.com>
 * @license    {LICENSE}
 * @version    $Revision$
 */

$dPconfig["{NAME_CANONICAL}"] = array(
);
