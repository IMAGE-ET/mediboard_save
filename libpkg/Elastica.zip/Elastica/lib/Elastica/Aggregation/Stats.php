<?php

namespace Elastica\Aggregation;

/**
 * Class Stats
 * @package Elastica\Aggregation
 * @link http://www.elasticsearch.org/guide/en/elasticsearch/reference/master/search-aggregations-metrics-stats-aggregation.html
 */
class Stats extends AbstractSimpleAggregation
{

} 