-- phpMyAdmin SQL Dump
-- version 4.0.5
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Lun 09 Septembre 2013 à 17:31
-- Version du serveur: 5.5.28
-- Version de PHP: 5.3.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `sae`
--

-- --------------------------------------------------------

--
-- Structure de la table `type_activite`
--

CREATE TABLE IF NOT EXISTS `type_activite` (
  `code` bigint(3) unsigned NOT NULL,
  `libelle` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `type_activite`
--

INSERT INTO `type_activite` (`code`, `libelle`) VALUES
(1, 'Administration'),
(2, 'Service hôteliers et techniques'),
(3, 'Hospitalisation complète (non compris hospitalisation de semaine)'),
(4, 'Hospitalisation de jour'),
(5, 'Hospitalisation de nuit'),
(6, 'Hospitalisation à domicile'),
(7, 'Consultations, soins externes'),
(8, 'Bloc opératoire (y compris obstétrical et gynécologique)'),
(9, 'Autres unités médico-techniques (anesthésiologie, explorations fonctionnelles, rééducation et réadaptation fonctionnelles, pharmacie)'),
(10, 'Accueil des urgences'),
(11, 'Hébergement complet ou internat (non compris internat de semaine)'),
(12, 'Hébergement de nuit en structure regroupée'),
(13, 'Semi-internat'),
(14, 'Externat'),
(15, 'Placement en famille d''accueil (strictement social)'),
(16, 'Prestations sur le lieu de vie (non compris placement familial)'),
(17, 'Internat de semaine'),
(18, 'Hébergement de nuit en structure éclatée'),
(19, 'Traitements et cures ambulatoires'),
(20, 'Hospitalisation de semaine'),
(21, 'Accueil de jour'),
(23, 'Anesthésie ou chirurgie ambulatoires'),
(24, 'Accueil et prise en charge en service d''accueil familial thérapeutique psychiatrique'),
(25, 'Hébergement temporaire de week-end ou de vacances'),
(26, 'Analyses médicales biologiques'),
(28, 'Consultations dentaires et soins dentaires'),
(30, 'Stockage d''organes et de produits humains'),
(31, 'Transport de malades'),
(32, 'Radiologie (radiodiagnostic et radiothérapie), imagerie médicale'),
(33, 'Recherche'),
(34, 'Enseignement'),
(37, 'Accueil et prise en charge en appartement thérapeutique psychiatrique'),
(38, 'Accueil et prise en charge en centre de posture psychiatrique'),
(39, 'Accueil et prise en charge en centre de crise psychiatrique'),
(40, 'Commerce de détail des biens à usage médical'),
(41, 'Commerce en gros de produits à usage médical ou vétérinaire'),
(97, 'Activité non dénommée ailleurs');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
