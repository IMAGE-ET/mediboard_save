<?php /* $Id: $ */

/**
 *	@package Mediboard
 *	@subpackage dPmateriel
 *	@version $Revision: $
 *  @author S�bastien Fillonneau
 */
 
global $AppUI, $canRead, $canEdit, $m;

if (!$canEdit) {
	$AppUI->redirect( "m=system&a=access_denied" );
}
 
require_once( $AppUI->getModuleClass("dPmateriel", "materiel") );

$materiel_id = mbGetValueFromGetOrSession("materiel_id", null);

$materiel=new CMateriel;
$materiel->load($materiel_id);
$materiel->LoadRefsBack();

// Cr�ation du template
require_once( $AppUI->getSystemClass("smartydp"));
$smarty = new CSmartyDP;
$smarty->assign("materiel", $materiel);
$smarty->display('vw_edit_materiel.tpl');
?>