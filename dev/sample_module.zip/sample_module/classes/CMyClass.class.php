<?php 
/**
 * $Id$
 * 
 * @package    Mediboard
 * @subpackage {NAME_CANONICAL}
 * @author     SARL OpenXtrem <dev@openxtrem.com>
 * @license    {LICENSE}
 * @version    $Revision$
 */

/**
 * My class
 */
class CMyClass extends CMbObject {
  public $my_class_id;

  public $name;

  /** @var CBackObject[] */
  public $_ref_backs;

  /** @var CFwdObject */
  public $_ref_fwd;

  /**
   * @see parent::getSpec()
   */
  function getSpec() {
    $spec = parent::getSpec();
    $spec->table = 'my_class';
    $spec->key   = 'my_class_id';
    return $spec;
  }

  /**
   * @see parent::getBackProps()
   */
  function getBackProps() {
    $backProps = parent::getBackProps();
    $backProps["backs"] = "CBack my_class_id";
    return $backProps;
  }

  /**
   * @see parent::getProps()
   */
  function getProps() {
    $props = parent::getProps();
    $props["name"] = "str notNull maxLength|50 seekable show|0";
    return $props;
  }

  /**
   * @see parent::updateFormFields()
   */
  function updateFormFields() {
    parent::updateFormFields();
    $this->_view = $this->name;
  }

  /**
   * @see parent::loadRefsBack()
   */
  function loadRefsBack() {
    return $this->_ref_backs = $this->loadBackRefs("backs");
  }
}
