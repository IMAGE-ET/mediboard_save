<?php

namespace Elastica\Aggregation;


/**
 * Class Avg
 * @package Elastica\Aggregation
 * @link http://www.elasticsearch.org/guide/en/elasticsearch/reference/master/search-aggregations-metrics-avg-aggregation.html
 */
class Avg extends AbstractSimpleAggregation
{

} 