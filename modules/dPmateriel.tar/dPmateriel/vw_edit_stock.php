<?php /* $Id: $ */

/**
 *	@package Mediboard
 *	@subpackage dPmateriel
 *	@version $Revision: $
 *  @author S�bastien Fillonneau
 */
 
global $AppUI, $canRead, $canEdit, $m;

if (!$canEdit) {
	$AppUI->redirect( "m=system&a=access_denied" );
}

require_once( $AppUI->getModuleClass("dPmateriel", "stock") );
require_once( $AppUI->getModuleClass("dPmateriel", "materiel") );
require_once($AppUI->getModuleClass("mediusers", "groups"));

$stock_id = mbGetValueFromGetOrSession("stock_id", null);

$stock=new CStock;
$stock->load($stock_id);

// Liste des Groupes
$Groupes = new CGroups;
$listGroupes = $Groupes->loadList();

//Liste du mat�riel
$Materiel = new CMateriel;
$listMateriel = $Materiel->loadList();

// Cr�ation du template
require_once( $AppUI->getSystemClass("smartydp"));
$smarty = new CSmartyDP;
$smarty->assign("stock", $stock);
$smarty->assign("listGroupes", $listGroupes);
$smarty->assign("listMateriel", $listMateriel);
$smarty->display('vw_edit_stock.tpl');
?>