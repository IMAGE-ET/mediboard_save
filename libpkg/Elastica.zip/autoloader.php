<?php 

/**
 * $Id$
 *  
 * @category ${Module}
 * @package  Mediboard
 * @author   SARL OpenXtrem <dev@openxtrem.com>
 * @license  GNU General Public License, see http://www.gnu.org/licenses/gpl.html 
 * @link     http://www.mediboard.org */

spl_autoload_register(function($class){
  if (0 === strpos($class, "Elastica")) {
    $file = "lib" . DIRECTORY_SEPARATOR . str_replace('\\', DIRECTORY_SEPARATOR, $class);
    
    $file = realpath(__DIR__. DIRECTORY_SEPARATOR . $file . '.php');
    if (file_exists($file)) {
      require_once $file;
    }
  }
});