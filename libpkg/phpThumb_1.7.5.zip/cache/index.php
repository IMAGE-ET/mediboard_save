<?php
header('Location: /');
exit;
?>