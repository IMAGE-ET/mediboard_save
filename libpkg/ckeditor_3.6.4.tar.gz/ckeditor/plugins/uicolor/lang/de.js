﻿CKEDITOR.plugins.setLang('uicolor','de',{uicolor:{title:'UI Pipette',preview:'Live-Vorschau',config:"Fügen Sie diese Zeichenfolge in die 'config.js' Datei.",predefined:'Vordefinierte Farbsätze'}});
