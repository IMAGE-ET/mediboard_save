<?php

namespace Elastica\Exception;

/**
 * JSON Parse exception
 *
 * @package Elastica
 */
class JSONParseException extends \RuntimeException implements ExceptionInterface
{
}
