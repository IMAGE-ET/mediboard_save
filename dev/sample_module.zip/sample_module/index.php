<?php 
/**
 * $Id$
 * 
 * @package    Mediboard
 * @subpackage {NAME_CANONICAL}
 * @author     SARL OpenXtrem <dev@openxtrem.com>
 * @license    {LICENSE}
 * @version    $Revision$
 */

$module = CModule::getInstalled(basename(dirname(__FILE__)));

//$module->registerTab('vw_idx_my_tab',        TAB_READ);