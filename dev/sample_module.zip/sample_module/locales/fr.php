<?php
$locales['module-{NAME_CANONICAL}-court'] = '{NAME_SHORT}';
$locales['module-{NAME_CANONICAL}-long'] = '{NAME_LONG}';
?>