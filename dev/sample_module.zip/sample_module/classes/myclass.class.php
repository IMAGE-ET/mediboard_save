<?php
/**
 * MyClass description
 *  
 * @category [SAMPLE]
 * @package  Mediboard
 * @author   SARL OpenXtrem <dev@openxtrem.com>
 * @license  GNU General Public License, see http://www.gnu.org/licenses/gpl.html 
 * @version  SVN: $Id$ 
 * @link     http://www.mediboard.org
 */

class CMyClass extends CMbObject {
  var $my_class_id   = null;
  
  var $name          = null;
  
  var $_ref_backs    = null;

  function getSpec() {
    $spec = parent::getSpec();
    $spec->table = 'my_class';
    $spec->key   = 'my_class_id';
    return $spec;
  }

  function getBackProps() {
    $backProps = parent::getBackProps();
    $backProps['backs'] = 'CBack my_class_id';
    return $backProps;
  }

  function getProps() {
    $specs = parent::getProps();
    $specs['name'] = 'str notNull maxLength|50 seekable show|0';
    return $specs;
  }

  function updateFormFields() {
    parent::updateFormFields();
    $this->_view = $this->name;
  }

  function loadRefsBack() {
    $this->_ref_backs = $this->loadBackRefs('backs');
  }
}
