<?php /* $Id: $ */

/**
 *	@package Mediboard
 *	@subpackage dPmateriel
 *	@version $Revision: $
 *  @author S�bastien Fillonneau
 */
 
// MODULE CONFIGURATION DEFINITION
$config = array();
$config["mod_name"] = "dPmateriel";
$config["mod_version"] = "0.1";
$config["mod_directory"] = "dPmateriel";
$config["mod_setup_class"] = "CSetupdPmateriel";
$config["mod_type"] = "user";
$config["mod_ui_name"] = "Stocks Mat�riel";
$config["mod_ui_icon"] = "dPmateriel.png";
$config["mod_description"] = "Gestion du stock du mat�riel";
$config["mod_config"] = true;

if (@$a == "setup") {
  echo dPshowModuleConfig( $config );
}

class CSetupdPmateriel {

  function configure() {
    global $AppUI;
    $AppUI->redirect( "m=dPmateriel&a=configure" );
    return true;
  }

  function remove() {
    db_exec( "DROP TABLE materiel;" );
    db_exec( "DROP TABLE stock;" );
    return null;
  }

  function upgrade($old_version) {
    switch ($old_version) {
      case "all":
      case "0.1":
        return "0.1";
    }
    return false;
  }

  function install() {
    $sql = "CREATE TABLE materiel (
          `materiel_id` int(11) NOT NULL auto_increment,
          `nom` VARCHAR(50) NOT NULL,
          `code_barre` int(11) default NULL,
          `description` TEXT default '',
          PRIMARY KEY  (materiel_id)
          ) TYPE=MyISAM COMMENT='Table du materiel';";
    db_exec( $sql ); db_error();
    $sql = "CREATE TABLE stock (
            stock_id int(11) NOT NULL auto_increment,
            materiel_id int(11) NOT NULL,
            group_id int(11) NOT NULL,
            seuil_cmd int(11) default NULL,
            quantite int(11) default NULL,					
            PRIMARY KEY (stock_id),
            UNIQUE KEY `materiel_id` (`materiel_id`,`group_id`)		
            ) TYPE=MyISAM COMMENT='Table des stock du materiel';";
    db_exec( $sql ); db_error();
    $this->upgrade("all");
    return null;
  }
}

?>