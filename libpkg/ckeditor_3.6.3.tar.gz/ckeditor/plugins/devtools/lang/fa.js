﻿CKEDITOR.plugins.setLang('devtools','fa',{devTools:{title:'اطلاعات عنصر',dialogName:'نام پنجره محاورهای',tabName:'نام برگه',elementId:'ID عنصر',elementType:'نوع عنصر'}});
