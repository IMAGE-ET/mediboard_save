<?php

namespace Elastica\Suggest\CandidateGenerator;


use Elastica\Param;

class AbstractCandidateGenerator extends Param
{

} 