<?php 
/**
 * $Id$
 * 
 * @package    Mediboard
 * @subpackage {NAME_CANONICAL}
 * @author     SARL OpenXtrem <dev@openxtrem.com>
 * @license    {LICENSE}
 * @version    $Revision$
 */

// Pr�f�rences par Module