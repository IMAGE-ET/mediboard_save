<?php 
/**
 * $Id$
 * 
 * @package    Mediboard
 * @subpackage {NAME_CANONICAL}
 * @author     SARL OpenXtrem <dev@openxtrem.com>
 * @license    {LICENSE}
 * @version    $Revision$
 */

class CMyClass extends CMbObject {
  var $my_class_id   = null;
  
  var $name          = null;
  
  var $_ref_backs    = null;

  function getSpec() {
    $spec = parent::getSpec();
    $spec->table = 'my_class';
    $spec->key   = 'my_class_id';
    return $spec;
  }

  function getBackProps() {
    $backProps = parent::getBackProps();
    $backProps["backs"] = "CBack my_class_id";
    return $backProps;
  }

  function getProps() {
    $props = parent::getProps();
    $props["name"] = "str notNull maxLength|50 seekable show|0";
    return $props;
  }

  function updateFormFields() {
    parent::updateFormFields();
    $this->_view = $this->name;
  }

  function loadRefsBack() {
    return $this->_ref_backs = $this->loadBackRefs("backs");
  }
}
