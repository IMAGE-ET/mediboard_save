<?php
namespace Elastica\Exception;

/**
 * QueryBuilder exception
 *
 * @package Elastica
 * @author Manuel Andreo Garcia <andreo.garcia@googlemail.com>
 */
class QueryBuilderException extends \RuntimeException implements ExceptionInterface
{
}
