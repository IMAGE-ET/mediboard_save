# MySQL Navigator Xport
# Database: bcbges
# root@UCMIKE

# CREATE DATABASE bcbges;
# USE bcbges;

#
# Table structure for table 'Attribut'
#

DROP TABLE IF EXISTS ATTRIBUT;
CREATE TABLE `ATTRIBUT` (
  `CODE` int(11) NOT NULL default '0',
  `LIBELLE` text NOT NULL,
  `LIBELLE_MAJ` text NOT NULL,
  UNIQUE KEY `PK_ATTRIBUT` (`CODE`),
  KEY `IX_ATTRIBUT` (`LIBELLE_MAJ`(255))
) TYPE=MyISAM;

#
# Table structure for table 'CIP_Attribut'
#

DROP TABLE IF EXISTS CIP_ATTRIBUT;
CREATE TABLE `CIP_ATTRIBUT` (
  `CODEETABLISSEMENT` int(11) NOT NULL default '0',
  `CODECIP` varchar(7) NOT NULL default '',
  `CODE` int(11) NOT NULL default '0',
  PRIMARY KEY  (`CODEETABLISSEMENT`,`CODECIP`,`CODE`),
  KEY `IX_CIP_ATTRIBUT` (`CODECIP`),
  KEY `IX_CIP_ATTRIBUT_1` (`CODEETABLISSEMENT`),
  KEY `IX_CIP_ATTRIBUT_2` (`CODE`)
) TYPE=MyISAM;

#
# Table structure for table 'Connexions'
#

DROP TABLE IF EXISTS CONNEXIONS;
CREATE TABLE `CONNEXIONS` (
  `DATE_CONNEXION` char(10) NOT NULL default '',
  `ID_UTILISATEUR` int(11) NOT NULL default '0',
  `COMPTEUR` int(11) default NULL,
  PRIMARY KEY  (`DATE_CONNEXION`,`ID_UTILISATEUR`),
  KEY `IX_CONNEXIONS` (`DATE_CONNEXION`),
  KEY `IX_CONNEXIONS_1` (`ID_UTILISATEUR`)
) TYPE=MyISAM;

#
# Table structure for table 'DataSession'
#

DROP TABLE IF EXISTS DATASESSION;
CREATE TABLE `DATASESSION` (
  `IDSESSION` varchar(255) NOT NULL default '""',
  `NUMEROLIGNE` int(11) default NULL,
  `TYPEINFO` int(11) NOT NULL default '0',
  `TEXTE` varchar(255) default NULL,
  KEY `IX_DATASESSION` (`IDSESSION`),
  KEY `IX_DATASESSION_1` (`NUMEROLIGNE`),
  KEY `IX_DATASESSION_2` (`TYPEINFO`)
) TYPE=MyISAM;

#
# Table structure for table 'Etablissements'
#

DROP TABLE IF EXISTS ETABLISSEMENTS;
CREATE TABLE `ETABLISSEMENTS` (
  `CODE` int(11) NOT NULL default '0',
  `NOM` varchar(50) NOT NULL default '',
  `ADRESSE1` varchar(100) default NULL,
  `ADRESSE2` varchar(100) default NULL,
  `CODEPOSTAL` varchar(5) default NULL,
  `VILLE` varchar(30) default NULL,
  `TEL` varchar(16) default NULL,
  `FAX` varchar(16) default NULL,
  `EMAIL` varchar(50) default NULL,
  PRIMARY KEY  (`CODE`)
) TYPE=MyISAM;

#
# Table structure for table 'LivretTherapeutique'
#

DROP TABLE IF EXISTS LIVRETTHERAPEUTIQUE;
CREATE TABLE `LIVRETTHERAPEUTIQUE` (
  `CODEETABLISSEMENT` int(11) NOT NULL default '0',
  `CODECIP` varchar(7) NOT NULL default '',
  `PRIXHOPITAL` double default NULL,
  `PRIXVILLE` double default NULL,
  `DATEPRIXHOPITAL` varchar(10) default NULL,
  `DATEPRIXVILLE` varchar(10) default NULL,
  `CODEINTERNE` varchar(10) default NULL,
  `COMMENTAIRE` text,
  PRIMARY KEY  (`CODEETABLISSEMENT`,`CODECIP`),
  KEY `IX_LIVRETTHERAPEUTIQUE` (`CODEETABLISSEMENT`)
) TYPE=MyISAM;

#
# Table structure for table 'Utilisateurs'
#

DROP TABLE IF EXISTS UTILISATEURS;
CREATE TABLE `UTILISATEURS` (
  `CODE` int(11) NOT NULL default '0',
  `LOGIN` varchar(50) default NULL,
  `MOTDEPASSE` varchar(15) default NULL,
  `CODEETABLISSEMENT` int(11) default NULL,
  `NOM` varchar(50) default NULL,
  `PRENOM` varchar(50) default NULL,
  `FONCTION` varchar(50) default NULL,
  `GESTIONETABLISSEMENT` int(11) default NULL,
  `GESTIONLIVRET` int(11) default NULL,
  `GESTIONUTILISATEUR` int(11) default NULL,
  `GESTIONOUTILS` int(11) default NULL,
  `GESTIONPASSWORD` int(11) default '1',
  PRIMARY KEY  (`CODE`)
) TYPE=MyISAM;

INSERT INTO ETABLISSEMENTS VALUES(1, 'Test', '', '', '', '', '', '', '');

INSERT INTO UTILISATEURS VALUES(1, 'admin', 'admin', 1, 'admin', '', '', 1, 1, 1, 1, 1);
